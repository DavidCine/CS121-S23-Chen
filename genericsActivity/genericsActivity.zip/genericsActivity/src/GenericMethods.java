public class GenericMethods {
}
